document.addEventListener('DOMContentLoaded', function () {
    document.getElementById("skipButton").addEventListener("click", myFunction);
    
    function myFunction(){
        chrome.tabs.query({'active': true, 'lastFocusedWindow': true}, function (tabs) {
            try{
                var  url = tabs[0].url;
                var info = "=http"; // where
                var split = url.split(info,2); //split
                var after = split[1]; // second
              var rep1 =   after.replace("%3A", ":"); // raplace
              var rep2 = rep1.replace(/%2F/g,"/"); //replace
             chrome.tabs.create({'url':"http"+rep2});
            }catch(error) 
            {
               
            }
          
      
            
        });
    


       
    
    }
}, false)
